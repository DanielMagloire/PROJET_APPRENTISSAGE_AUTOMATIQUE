//**********************************************//
//                                              //
//              TP2 - APPRENTISSAGE             //
//                                              //
//       Implementation Perceptron Multiple     //
//                                              //
//        Prepare par :                         //
//          ELIODOR Ednalson Guy Mirlin - P21   //
//          MEDOU Daniel Magloire - P21         //
//                                              //
//**********************************************//

#include <iostream>
#include <fstream>
#include <string.h>
#include <math.h>
#include <algorithm>
#include <vector>

//Definition des parametres pour la base Leukima
#define nombredeLigne_train_Leukimia 38
#define nombredeLigne_test_Leukimia 34
#define nombredeColonne_base_Leukimia 7130

//Definition des parametres pour la base SPAM
#define nombredeLigne_train_SPAM 3068
#define nombredeColonne_train_SPAM 59
#define nombredeLigne_test_SPAM 1533
#define nombredeColonne_test_SPAM 59

//Definition des parametres pour la base Ovarian
#define nombredeLigne_train_Ovarian 169
#define nombredeColonne_train_Ovarian 15156
#define nombredeLigne_test_Ovarian 84
#define nombredeColonne_test_Ovarian 15156

//Definition des parametres pour la base test
#define nombredeLigne_train_basetest 23
#define nombredeColonne_train_basetest 4
#define nombredeLigne_test_basetest 23
#define nombredeColonne_test_basetest 4

using namespace std;

//Variables Globales pour le programme
int nombredeColonne_trn = 0;
int nombredeLigne_trn = 0;
int nombredeColonne_tst = 0;
int nombredeLigne_tst = 0;
int nombredeClasse = 0;

//lecture des donnees depuis un fichier
double **read_data(string file, string type) {
    int nombredeLigne = 0, nombredeColonne = 0;
    double **data;
    ifstream file_reader(file.c_str(), ios::in);
    if (file_reader) // ouverture du fichier
    {

        //Definition de nombre de ligne et de colonne de la basse de donnees a utilisee pour l'experimentation
        if (file.compare("data/spam/spam.trn") != 0 && file.compare("data/ovarian/ovarian.trn") != 0 && file.compare("basetest.trn") != 0
                && type.compare("trn") == 0) {
		if(file.compare("data/leukemia/ALLAML.trn")==0){
                nombredeLigne_trn=nombredeLigne_train_Leukimia;
                nombredeColonne_trn=nombredeColonne_base_Leukimia;
            }
            nombredeColonne_trn++;
            nombredeLigne = nombredeLigne_trn;
            nombredeColonne = nombredeColonne_trn;
        }

        if (file.compare("data/spam/spam.tst") != 0 && file.compare("data/ovarian/ovarian.tst") != 0 && file.compare("basetest.tst") !=0
                && type.compare("tst") == 0) {
		if(file.compare("data/leukemia/ALLAML.tst")==0){
		file.erase(file.begin()+13, file.end());
                nombredeLigne_tst=nombredeLigne_test_Leukimia;
                nombredeColonne_tst=nombredeColonne_base_Leukimia;
            }

            nombredeColonne_tst++;
            nombredeLigne = nombredeLigne_tst;
            nombredeColonne = nombredeColonne_tst;
        }

        if (file.compare("data/spam/spam.trn") == 0) {
            nombredeLigne_trn = nombredeLigne_train_SPAM;
            nombredeColonne_trn = nombredeColonne_train_SPAM;
            nombredeLigne = nombredeLigne_trn;
            nombredeColonne = nombredeColonne_trn;
        }

        if (file.compare("data/spam/spam.tst") == 0) {
            nombredeLigne_tst = nombredeLigne_test_SPAM;
            nombredeColonne_tst = nombredeColonne_test_SPAM;
            nombredeLigne = nombredeLigne_tst;
            nombredeColonne = nombredeColonne_tst;
	    file.erase(file.begin()+9, file.end());

        }

        if (file.compare("data/ovarian/ovarian.trn") == 0) {
            nombredeLigne_trn = nombredeLigne_train_Ovarian;
            nombredeColonne_trn = nombredeColonne_train_Ovarian;
            nombredeLigne = nombredeLigne_trn;
            nombredeColonne = nombredeColonne_trn;
        }

        if (file.compare("data/ovarian/ovarian.tst") == 0) {
            nombredeLigne_tst = nombredeLigne_test_Ovarian;
            nombredeColonne_tst = nombredeColonne_test_Ovarian;
            nombredeLigne = nombredeLigne_tst;
            nombredeColonne = nombredeColonne_tst;
	    file.erase(file.begin()+12, file.end());

        }
        if (file.compare("basetest.trn") == 0) {
            nombredeLigne_trn = nombredeLigne_train_basetest;
            nombredeColonne_trn = nombredeColonne_train_basetest;
            nombredeLigne = nombredeLigne_trn;
            nombredeColonne = nombredeColonne_trn;
        }

        if (file.compare("basetest.tst") == 0) {
            nombredeLigne_tst = nombredeLigne_test_basetest;
            nombredeColonne_tst = nombredeColonne_test_basetest;
            nombredeLigne = nombredeLigne_tst;
            nombredeColonne = nombredeColonne_tst;
	    file.erase(file.begin()+8, file.end());

        }

        // Creation de la matrice pour stocker les donnees
        data = new double* [nombredeLigne];
        for (int i = 0; i < nombredeLigne; i++) {
            data[i] = new double[nombredeColonne];
        }

        //Fixation de la premiere colonne a 1 - biais
        for (int i = 0; i < nombredeLigne; i++) {
            data[i][0] = 1;
        }

         //Stockage des donnees dans la matrice
        for (int k = 0; k < nombredeLigne; k++) {
            for (int l = 1; l < nombredeColonne; l++) {
                file_reader >> data[k][l];
            }
        }

        file_reader.close(); // Fermeture du fichier
    } else {
        cerr << "ERROR - Impossible d'ouvrir le fichier - ERROR !" << endl;
    }

    return data;
}

//Comparaison de ligne
bool comparaisonLigne(double* premiereLigne, double* deuxiemeLigne) {
    return (premiereLigne[1] < deuxiemeLigne[1]);
}

//Normalisation du jeu de donnees
double ** normalisationDesDonnees(double** data, int nombredeLigne, int nombredeColonne){

   double* col;
   col = new double[nombredeLigne];

   for(int i=0; i< nombredeColonne-1; i++){
        for(int j=0; j< nombredeLigne; j++){
            col[j] = data[j][i];
        }
     std::sort(col, col + nombredeLigne);
     for(int j=0; j< nombredeLigne; j++){

         data[j][i] = (data[j][i]-col[0])/(col[nombredeLigne-1]-col[0]);

     }
   }

   return data;
}

//prediction des classes a partir des entrees et de la base elle meme
double predictionClasse(double * poids, double *ligne){


    double sortie =0;

    for(int i =0; i < 3; i++){

        sortie += poids[i]*ligne[i];

    }
    sortie = 1/(1+exp(-1*sortie));


    return sortie;
}

//Propagation des valeurs d'entrees dans le reseau de neurones
double *propagation(double **matricedePoids, double *ligne){

    double *out;
    out = new double[4];
    out[0] = 1;

    for(int i = 1; i< 3; i++){
        out[i] = predictionClasse(matricedePoids[i-1], ligne);
    }

        out[3] = predictionClasse(matricedePoids[2],out);

        return out;
}

//execution de la backpropagation
double **back_propagation(double *out, double **matricedePoids, double *ligne, double pasApprentissage){

    double *variation;
    double so1;
    variation = new double[9];
    double ** miseAJourMatrice;
    miseAJourMatrice = new double*[3];
    for(int i =0; i < 3; i++){
        miseAJourMatrice[i] = new double[3];
    }

    //computing variation values for all weigth and biais
    so1 = -1*(ligne[nombredeColonne_trn-1]-out[3])* out[3]*(1-out[3]);
    variation[5] = so1*out[2];
    variation[4] = so1*out[1];
    variation[3] = so1*matricedePoids[2][2]*out[2]*(1-out[2])*ligne[2];
     variation[2] = so1*matricedePoids[2][2]*out[2]*(1-out[2])*ligne[1];
      variation[1] = so1*matricedePoids[2][1]*out[1]*(1-out[1])*ligne[2];
       variation[0] = so1*matricedePoids[2][1]*out[1]*(1-out[1])*ligne[1];

       variation[6] = so1;//biais 3
       variation[7] = so1*matricedePoids[2][2]*out[2]*(1-out[2]); // biais 2
       variation[8] =  so1*matricedePoids[2][1]*out[1]*(1-out[1]); // biais 1

       //update weight and biais
    miseAJourMatrice[2][2] = matricedePoids[2][2]-pasApprentissage*variation[5];
    miseAJourMatrice[2][1] = matricedePoids[2][1] - pasApprentissage*variation[4];
    miseAJourMatrice[1][2] = matricedePoids[1][2] - pasApprentissage*variation[3];
     miseAJourMatrice[1][1] = matricedePoids[1][1] - pasApprentissage*variation[2];
    miseAJourMatrice[0][2] = matricedePoids[0][2] - pasApprentissage*variation[1];
    miseAJourMatrice[0][1] = matricedePoids[0][1] - pasApprentissage*variation[0];
    miseAJourMatrice[2][0] = matricedePoids[2][0] - pasApprentissage*variation[6];//biais 3
    miseAJourMatrice[1][0] = matricedePoids[1][0] - pasApprentissage*variation[7];// biais 2
    miseAJourMatrice[0][0] = matricedePoids[0][0] - pasApprentissage*variation[8];//biais 1


    return miseAJourMatrice;
}

//computing of weigth that fit to the training set
double** preceptron_multiplle(double** train_set, double pasApprentissage, int max_iter) {

    double **poids;
    poids = new double*[3];
    for(int i =0; i < 3; i++){
        poids[i] = new double[3];
    }

     //assigning random values to weight at their initialisation
    for(int i =0; i < 3; i++ ){
        for(int j =0; j < 3; j++ ){
       poids[i][j] = rand() / double(RAND_MAX);
        }
    }

    //backpropagation
    for(int j= 0; j < max_iter ; j++){
        for(int k =0; k< nombredeLigne_trn; k++){
          poids = back_propagation(propagation(poids,train_set[k]),poids,train_set[k],pasApprentissage) ;
        }
    }

    return poids;
}

//computing of the classification performance
double tauxBonClassement(int **matriceConfusion) {
    double taux = 0;
    double sommeDiagonale = 0;
    double sommeTotale = 0;

    for (int i = 0; i < nombredeClasse; i++) {
        for (int j = 0; j < nombredeClasse; j++) {
            if (i == j) {
                sommeDiagonale += matriceConfusion[i][j];
            }
            sommeTotale += matriceConfusion[i][j];
        }
    }
    taux = sommeDiagonale / sommeTotale;
    return taux;

}


int main(int argc, char** argv) {

    //lecture et stockage des parametres du programme
    char *trn = argv[1];
    char *tst = argv[2];
    char train_file[50] = "";
    strcat(train_file, trn);

    char test_file[50] = "";
    strcat(test_file, tst);

    double pasApprentissage;
    pasApprentissage = atof(argv[3]);
    int max_iter;
    max_iter = atoi(argv[4]);


    double** training;
    double** test;


    //Lecture des donnees dans la base specifique

    training = read_data(train_file, "trn");
    test = read_data(test_file, "tst");

     //Storage of expected classes
    int supposed_classes [nombredeLigne_tst];
    for (int i = 0; i < nombredeLigne_tst; i++) {
        supposed_classes[i] = test[i][nombredeColonne_tst - 1];
    }

     //Determination of number of expected classes
    std::sort(supposed_classes, supposed_classes + nombredeLigne_tst);
    int compt = 0;
    std::vector<int> classes;
    for (int i = 0; i < nombredeLigne_tst; i++) {

        compt = std::count(supposed_classes, supposed_classes +
                nombredeLigne_tst, supposed_classes[i]);
        classes.push_back(supposed_classes[i]);
        i = i + compt - 1;
        nombredeClasse++;

    }

   //creation of the confusion matrix
    int **matricedeConfusion;
    matricedeConfusion = new int*[nombredeClasse];
    for (int j = 0; j < nombredeClasse; j++) {
        matricedeConfusion[j] = new int [nombredeClasse];
        for (int n = 0; n < nombredeClasse; n++) {
            matricedeConfusion[j][n] = 0;
        }
    }

    //computing of predited classes
    double** poids;
    poids = new double*[3];
    for(int i =0; i < 3; i++){
        poids[i] = new double[3];
    }
    poids = preceptron_multiplle(training, pasApprentissage, max_iter);

    int *prediction;
    prediction = new int[nombredeLigne_tst];


    for (int i = 0; i < nombredeLigne_tst; i++) {
        double* a = propagation(poids,test[i]);
        if(a[3]>0.5){
        prediction[i] = 1;}
        else{ prediction[i] =0;
        }
    }

    //Construction de la matrice de confusion
    for (int m = 0; m < nombredeLigne_tst; m++) {
        int pos1 = std::find(classes.begin(), classes.end(), (int) test[m][nombredeColonne_tst - 1]) - classes.begin();
        int pos2 = std::find(classes.begin(), classes.end(), (int) prediction[m]) - classes.begin();
        matricedeConfusion[pos1][pos2]++;
    }

     //Printing of number of classes, confusion matrix and performance
    cout << "nombre de classes : " << nombredeClasse << endl;
    cout << "Matrice de confusion"<< endl;

    for (int a = 0; a < nombredeClasse; a++) {
        for (int b = 0; b < nombredeClasse; b++) {
            cout << matricedeConfusion[a][b] << " ";
        }
        cout << endl;
    }

    cout << "le taux de bon classement est :" << tauxBonClassement(matricedeConfusion)*100 << "%" << endl;


    return 0;

}
